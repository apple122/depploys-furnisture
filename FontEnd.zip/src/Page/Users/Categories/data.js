export default {
    Mainurl: "http://localhost:3022",
    IMG: 'http://localhost:3022/profile/',

    POSTOMISE: '/Omise/check-credit-card',
    POSTSALE: '/v4/selltype/add',
    PATCHITEM: '/v2/items/patch/',

    Currency: '/currency/GET',

}