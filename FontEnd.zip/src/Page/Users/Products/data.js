export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    GETTYPE: '/v1/pro_type/get',
    GETITEM: '/v2/items/get',
}