export default {
    Mainurl: "http://localhost:3022",
    IMG: 'http://localhost:3022/profile/',

    GETUERS: '/Login/GetLogin',
    GETABOUT: '/About/GET',
}