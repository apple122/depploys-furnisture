export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    GET: '/v4/selltype/get',
    Currency: '/currency/GET',
}