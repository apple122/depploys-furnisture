import React from 'react'
import Login from './Login/Login'

export default function Admin() {
  return (
    <Login />
  )
}
