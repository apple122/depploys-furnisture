export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    GET: '/Follow/GET',
    POST: '/Follow/POST',
    DEL: '/Follow/DEL/',
    PATCH: '/Follow/PATCH/'
}