export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    GET: '/Login/GetLogin',
    GETA: '/About/GET',
    POST: '/About/POST',
    PATCH: '/About/PATCH/'
}