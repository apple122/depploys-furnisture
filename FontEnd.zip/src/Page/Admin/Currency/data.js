export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    POST: '/currency/post',
    GET: '/currency/GET',
    PATCH: '/Currency/PATCH/',
}