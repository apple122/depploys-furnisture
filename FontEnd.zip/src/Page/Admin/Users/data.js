export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    POST: '/Login/Create',
    GET: '/Login/GetLogin',
    PATCH: '/Login/patch/',
    DEL: '/Login/delete/',

    POSTLOGIN: '/Profile/POST'
}