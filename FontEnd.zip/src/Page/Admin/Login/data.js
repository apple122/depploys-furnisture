export default {
    Mainurl: "http://localhost:3022",

    LOGIN: '/Login/Login'
}