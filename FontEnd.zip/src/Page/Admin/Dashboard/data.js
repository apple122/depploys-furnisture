export default {
    Mainurl: "http://localhost:3022",

    GETCURRENCY: '/currency/GET',

    get: '/v1/pro_type/get',
    GETUsers: '/Login/GetLogin',
    GETITEMS: '/v2/items/get',
    GETSALE: '/v4/selltype/get',

}