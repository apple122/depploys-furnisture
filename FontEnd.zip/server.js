export default {
    Mainurl: "http://localhost:3022",
}
